#include<stdio.h>
int iteratorPowerOf2(int power);
int recursivePowerOf2(int power);
int  main()
{
	int power = 10;
	printf("2의 %d승의 값 =  %d\n" , power, iteratorPowerOf2(power) ) ;

	printf("2의 %d승의 값 =  %d\n" , power, recursivePowerOf2(power) ) ;

	getchar();
	return 0;
}

int iteratorPowerOf2(int power)
{
	// TODO
	return 0;  // 리턴값은 수정하세요.
}

int recursivePowerOf2(int power)
{
	// TODO
	return 0;  // 리턴값은 수정하세요.
}
